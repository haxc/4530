--[[
RA-MOD
]]--

module("luci.controller.RSS", package.seeall)

function index()
	
	if not nixio.fs.access("/etc/config/RSS") then
		return
	end

	local page
	page = entry({"admin", "services", "RSS"}, cbi("RSS"), _("RSS For PT"))
	page.i18n = "RSS"
	page.dependent = true
end
