--[[
RA-MOD
]]--

local fs = require "nixio.fs"

m = Map("RSS", translate("RSS For PT"))

s = m:section(TypedSection, "RSS", translate("Settings"))
s.anonymous = true

s:tab("basic", translate("Basic Settings"))
s:tab("feeds", translate("RSS Feeds"))

s:taboption("basic", Flag, "enable", translate("Enable")).rmempty = false

s:taboption("basic", Flag, "aria2", translate("Auto import to aria2 RPC")).rmempty = false

folder = s:taboption("basic", Value, "folder", translate("Torrent Folder"), translate("Where your torrent files save"))
folder.optional = false
folder.rmempty = false

interval = s:taboption("basic", Value, "interval", translate("Interval"), translate("Hours , zero mean run once"))
interval.optional = false
interval.datatype = "uinteger"
interval.default = "0"
interval.rmempty = false

maxtask = s:taboption("basic", Value, "maxtask", translate("Max Task"), translate("Max fetch per feed"))
maxtask.optional = false
maxtask.datatype = "uinteger"
maxtask.default = "3"
maxtask.rmempty = false

kwords = s:taboption("basic", Value, "keywords", translate("Keywords"), translate("ANY using asterisk , AND using ['plus'] , OR using [ 'space' , 'comma' , 'semicolon' ]"))
kwords.optional = false
kwords.default = "*"
kwords.rmempty = false

feeds = s:taboption("feeds", Value, "feeds", 
	translate("Put your RSS feeds here line by line"), 
	translate("Comment Using #"))

feeds.template = "cbi/tvalue"
feeds.rows = 20
feeds.wrap = "off"

function feeds.cfgvalue(self, section)
	return fs.readfile("/etc/RSS/feeds") or ""
end

function feeds.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		fs.writefile("/tmp/feeds", value)
		if (luci.sys.call("cmp -s /tmp/feeds /etc/RSS/feeds") == 1) then
			fs.writefile("/etc/RSS/feeds", value)
		end
		fs.remove("/tmp/feeds")
	end
end

return m
